package com.example.compras.activities

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.example.compras.R
import com.example.compras.adapter.ProductAdapter
import com.example.compras.databinding.ActivityMainBinding
import com.example.compras.model.Product
import com.google.gson.Gson
import org.json.JSONException

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var productList: MutableList<Product>
    private lateinit var productAdapter: ProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //setSupportActionBar(binding.toolbar)

        loadProducts()
        // Implementa la lógica para cargar las categorías en el Spinner
        // (implementar esta parte según tu lógica)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.carrito -> {
                openSecondActivity()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun openSecondActivity() {
        val intent = Intent(this, SecondActivity::class.java)
        startActivity(intent)
    }

    private fun loadProducts() {
        val requestQueue: RequestQueue = Volley.newRequestQueue(this)
        val url = "https://dummyjson.com/products"

        val jsonArrayRequest = JsonArrayRequest(Request.Method.GET, url, null,
            Response.Listener { response ->
                val gson = Gson()
                productList = mutableListOf()
                for (i in 0 until response.length()) {
                    try {
                        val jsonObject = response.getJSONObject(i)
                        val product = gson.fromJson(jsonObject.toString(), Product::class.java)
                        productList.add(product)
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
                displayProducts()
            },
            Response.ErrorListener {})

        requestQueue.add(jsonArrayRequest)
    }

    private fun displayProducts() {
        productAdapter = ProductAdapter(productList) { product ->
            // Implementa la lógica para añadir el producto al carrito
            // (implementar esta parte según tu lógica)
        }
        binding.recyclerViewProducts.adapter = productAdapter
    }
}